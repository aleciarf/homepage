(() => {
  const host=location.hostname;
  const services=host==='www.facebook.com'?['facebook','messenger']:host.endsWith('messenger.com')?['messenger']:host==='chat.google.com'?['chat']:['gmail'];
  const defaults={
    facebook:['[aria-label*="Notifications" i]','[aria-label*="notification" i][role="button"]'],
    messenger:['[aria-label*="Messenger" i]','[aria-label*="unread conversations" i]'],
    chat:['[aria-label*="unread chats" i]','[aria-label*="unread conversations" i]'],
    gmail:['a[href$="#inbox"]','a[href*="/#inbox"]','[aria-label^="Inbox" i]']
  };
  let overrides={},timer,stopped=false;
  const visible=node=>node.getClientRects().length>0;
  function readNode(node,attribute){
    if(!node||!visible(node))return null;
    if(attribute)return BadgeCountParser.numeric(attribute==='text'?node.textContent:node.getAttribute(attribute));
    for(const value of [node.getAttribute('aria-label'),node.getAttribute('title')]){
      const parsed=BadgeCountParser.numeric(value);if(parsed)return parsed;
    }
    // Only exact numeric badge text or a short explicit label is accepted.
    if(node.textContent.length<70){const p=BadgeCountParser.numeric(node.textContent);if(p)return p;}
    if(!node.matches('a,button,[role="button"],[role="link"]'))return null;
    for(const child of node.querySelectorAll('span')){
      if(visible(child)&&/^\s*\d[\d,]*\+?\s*$/.test(child.textContent)){const p=BadgeCountParser.numeric(child.textContent);if(p)return p;}
    }
    return null;
  }
  function detect(service){
    const custom=overrides[service];
    if(custom?.selector){try{return readNode(document.querySelector(custom.selector),custom.attribute||'text')}catch{return null}}
    for(const selector of defaults[service])for(const node of document.querySelectorAll(selector)){const result=readNode(node);if(result)return result;}
    return BadgeCountParser.titleCount(document.title,service);
  }
  async function scan(){
    if(stopped)return;
    try{
      for(const service of services){const result=detect(service);await chrome.storage.local.set({['count_'+service]:{service,count:result?.count??null,approximate:result?.approximate??false,updatedAt:Date.now(),status:result?'detected':'unknown'}});}
    }catch{stopped=true;observer.disconnect();clearInterval(interval);}
  }
  const schedule=()=>{clearTimeout(timer);timer=setTimeout(scan,1000)};
  const observer=new MutationObserver(schedule);
  observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,characterData:true,attributeFilter:['aria-label','title']});
  chrome.storage.local.get('selectors').then(data=>{overrides=data.selectors||{};scan()});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.selectors){overrides=changes.selectors.newValue||{};scan()}});
  const interval=setInterval(scan,15000);
  document.addEventListener('visibilitychange',scan);
})();
