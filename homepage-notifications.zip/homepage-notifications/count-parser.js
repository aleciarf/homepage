(function(root){
  function numeric(value){
    const text=String(value||'').trim().replace(/,/g,'');
    if(/^\d{1,5}\+?$/.test(text))return {count:Number(text.replace('+','')),approximate:text.endsWith('+')};
    const match=text.match(/^(?:Notifications?|Messenger)\s*(?:[:–-]\s*)?(\d{1,5})\s+unread(?: notifications?| messages?| conversations?)?$/i)||text.match(/^(?:Inbox|Notifications?|Messenger|Unread(?: messages?| conversations?| chats?)?)\s*[:(]?\s*(\d{1,5})\s*\)?$/i)||text.match(/^(\d{1,5})\s+(?:unread(?: messages?| conversations?| chats?)?|new notifications?)$/i);
    return match?{count:Number(match[1]),approximate:false}:null;
  }
  function titleCount(title,service){
    let m;
    if(service==='gmail')m=String(title).match(/^Inbox\s*\((\d[\d,]*)\)/i);
    if(service==='messenger')m=String(title).match(/^\((\d+)\)\s*Messenger\b/i);
    return m?{count:Number(m[1].replace(/,/g,'')),approximate:false}:null;
  }
  const api={numeric,titleCount};root.BadgeCountParser=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
