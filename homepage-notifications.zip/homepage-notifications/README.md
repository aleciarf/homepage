# Homepage notification badges

## Install on Windows (Edge / Chrome / Whale)

1. Extract this ZIP to a folder you will keep, such as Documents/homepage-notifications.
2. Open your browser's Extensions page: edge://extensions, chrome://extensions, or whale://extensions.
3. Enable Developer mode, choose **Load unpacked**, and select the folder containing manifest.json.
4. Reload any existing Facebook, Messenger, Google Chat, Gmail, and homepage tabs.
5. Keep the source sites open and signed in, in the same browser profile as the homepage. Pinning their tabs is convenient.
6. On the homepage, click the feature pencil, edit a shortcut, and choose its **Notification badge** source. Automatic also recognizes these sites by URL. Click the checkmark to finish.

Homepage: https://clover-desk-phuong-2026.gracegrace1509.chatgpt.site/

## Counts

The extension reads visible badges and explicit unread labels. It does not read message bodies, cookies, passwords, or network traffic. All stored data is local to your browser; the homepage receives only counts and update times. There are no external requests or cloud uploads.

Gmail reports the visible inbox unread count, which can represent unread conversations rather than individual messages. Messenger reports unread conversations when exposed. Facebook reports a notification badge when exposed. Google Chat reports a visible unread badge when exposed. It does not fabricate a total by counting messages or threads.

Automatic detection is conservative and is not guaranteed on every language, layout, or account. Facebook and Google Chat especially may not expose a readable number. Unknown counts hide the homepage badge; they are not shown as zero. If the extension cannot detect a badge you can see, open its popup and set a CSS selector for that number. Right-click the number → Inspect → right-click its element in developer tools → Copy → Copy selector. Select the number itself. Choose Text, Accessible label, or Title attribute depending on where that number is stored. Clear the selector to restore automatic detection.

Counts update after page changes and about every 15 seconds. Background-tab throttling or sleeping tabs can delay updates. After five minutes without a readable update, the homepage hides the badge. A zero is accepted only when an explicit zero can be read; zero badges are hidden.

Multiple accounts/tabs for the same service share one badge: the latest tab reading wins. For predictable results, keep one account/tab per service. On Facebook, the Messenger badge can supply the Messenger count too; a dedicated Messenger tab is usually clearer.

## Status and troubleshooting

Click the extension icon to see detected / unknown / stale / waiting states. If every service says waiting, reload the source pages after installing. If the homepage shows no badge but the popup has a fresh count, reload the homepage and check the shortcut's selected badge source. No badge appears for an empty shortcut slot.

This initial release was checked against synthetic badge/title fixtures and message validation tests. It has not been verified against your signed-in accounts, so a selector adjustment may be needed. Send a screenshot of the badge and the status popup if automatic detection misses it; do not send passwords or session cookies.

Phone Link and Gmail API login are not included in this browser-only release. Phone Link requires a separately installed Windows helper. This package has no Windows notification permissions.

Uninstall from the Extensions page to remove the add-on. Removing it does not affect your homepage bookmarks or icons.
