(() => {
  const services=['facebook','messenger','chat','gmail'];
  let stopped=false;
  async function publish(){
    if(stopped)return;
    try{
      const stored=await chrome.storage.local.get(services.map(s=>'count_'+s));
      const counts={};
      for(const service of services){const x=stored['count_'+service];if(x)counts[service]={count:x.count,approximate:!!x.approximate,updatedAt:x.updatedAt,status:x.status};}
      window.postMessage({type:'homepage-notification-counts-v1',counts},location.origin);
    }catch{stopped=true;clearInterval(interval)}
  }
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&Object.keys(changes).some(k=>k.startsWith('count_')))publish()});
  const interval=setInterval(publish,15000);publish();
  document.addEventListener('visibilitychange',publish);
})();
